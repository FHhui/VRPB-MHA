package org.uma.jmetal.util.solutionattribute.impl;

import org.uma.jmetal.solution.Solution;

/**
 * Created by cbarba on 24/3/15.
 */
@SuppressWarnings("serial")
public class DistanceToSolutionListAttribute extends GenericSolutionAttribute<Solution<?>,Double> {
}
